import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// VIN Submission types (in-memory storage, no DB table)
export interface VinSubmission {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  vinNumber: string;
  timestamp: string;
  status: "pending" | "paid" | "delivered";
}

export interface InsertVinSubmission {
  firstName: string;
  lastName: string;
  email: string;
  vinNumber: string;
  timestamp: string;
  status: "pending" | "paid" | "delivered";
}

// Contact Message types (in-memory storage, no DB table)
export interface ContactMessage {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  vinNumber: string | null;
  message: string;
  timestamp: string;
}

export interface InsertContactMessage {
  firstName: string;
  lastName: string;
  email: string;
  vinNumber: string | null;
  message: string;
  timestamp: string;
}
