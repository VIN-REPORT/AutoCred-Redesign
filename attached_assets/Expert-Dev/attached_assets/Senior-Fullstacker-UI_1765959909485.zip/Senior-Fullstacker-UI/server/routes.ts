import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

// Conditionally import PayPal if credentials are available
let paypalHandlers: any = null;
if (process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET) {
  try {
    paypalHandlers = require("./paypal");
  } catch (e) {
    console.warn("Failed to initialize PayPal:", e);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // PayPal routes - with graceful handling for missing credentials
  app.get("/api/paypal/setup", async (req, res) => {
    if (paypalHandlers) {
      await paypalHandlers.loadPaypalDefault(req, res);
    } else {
      res.status(503).json({ 
        error: "PayPal is not configured. Please add PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET secrets.",
        configured: false 
      });
    }
  });

  app.post("/api/paypal/order", async (req, res) => {
    if (paypalHandlers) {
      await paypalHandlers.createPaypalOrder(req, res);
    } else {
      res.status(503).json({ 
        error: "PayPal is not configured. Please add PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET secrets.",
        configured: false 
      });
    }
  });

  app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
    if (paypalHandlers) {
      await paypalHandlers.capturePaypalOrder(req, res);
    } else {
      res.status(503).json({ 
        error: "PayPal is not configured.",
        configured: false 
      });
    }
  });

  // VIN submission route
  app.post("/api/vin-submission", async (req, res) => {
    try {
      const { firstName, lastName, email, vinNumber, timestamp } = req.body;
      
      // Validate required fields
      if (!firstName || !lastName || !email || !vinNumber) {
        return res.status(400).json({ error: "All fields are required" });
      }

      // Validate VIN format
      if (vinNumber.length !== 17 || !/^[A-HJ-NPR-Z0-9]+$/i.test(vinNumber)) {
        return res.status(400).json({ error: "Invalid VIN format" });
      }

      // Store submission
      const submission = await storage.createVinSubmission({
        firstName,
        lastName,
        email,
        vinNumber: vinNumber.toUpperCase(),
        timestamp: timestamp || new Date().toISOString(),
        status: "pending",
      });

      // TODO: Send email via EmailJS (configured on frontend with placeholder credentials)
      
      res.status(201).json({ 
        success: true, 
        message: "VIN submission received. Please complete payment.",
        submissionId: submission.id 
      });
    } catch (error) {
      console.error("VIN submission error:", error);
      res.status(500).json({ error: "Failed to process submission" });
    }
  });

  // Contact form route
  app.post("/api/contact", async (req, res) => {
    try {
      const { firstName, lastName, email, vinNumber, message } = req.body;
      
      if (!firstName || !lastName || !email || !message) {
        return res.status(400).json({ error: "Required fields are missing" });
      }

      // Store contact message
      const contact = await storage.createContactMessage({
        firstName,
        lastName,
        email,
        vinNumber: vinNumber || null,
        message,
        timestamp: new Date().toISOString(),
      });

      res.status(201).json({ 
        success: true, 
        message: "Message received. We will respond shortly." 
      });
    } catch (error) {
      console.error("Contact form error:", error);
      res.status(500).json({ error: "Failed to send message" });
    }
  });

  return httpServer;
}
