# AutoCheckPro

## Overview

AutoCheckPro is a vehicle history report service website that allows users to purchase VIN reports for $20 USD. The application targets car buyers in USA, UK, Canada, Europe, and Australia who want to verify vehicle history before purchasing a used car. The site is designed as a premium, trust-building service with a clean white/light theme, professional animations, and a streamlined checkout flow.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with custom plugins for Replit integration
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **UI Components**: shadcn/ui component library (New York style) built on Radix UI primitives
- **Forms**: React Hook Form with Zod validation
- **Animations**: Framer Motion for smooth transitions and scroll-based animations
- **Email Integration**: EmailJS for client-side email sending (credentials placeholder)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **Build Process**: Custom build script using esbuild for server bundling and Vite for client
- **API Pattern**: RESTful endpoints under `/api` prefix
- **Development**: Hot module replacement via Vite middleware

### Data Storage
- **Database Schema**: PostgreSQL with Drizzle ORM (schema defined, DB can be provisioned)
- **Current Storage**: In-memory storage implementation (`MemStorage` class) as interim solution
- **Schema Location**: `shared/schema.ts` contains user, VIN submission, and contact message types
- **Migrations**: Drizzle Kit configured for PostgreSQL migrations in `/migrations` directory

### Payment Processing
- **Provider**: PayPal SDK integration
- **Environment**: Sandbox for development, Production for live
- **Flow**: Create order → Capture order pattern
- **Price Point**: $20 USD per VIN report

### Project Structure
```
client/           # React frontend application
  src/
    components/ui/  # shadcn/ui components
    pages/          # Route components
    hooks/          # Custom React hooks
    lib/            # Utilities and query client
server/           # Express backend
  routes.ts       # API endpoint definitions
  paypal.ts       # PayPal integration (critical - do not modify)
  storage.ts      # Data storage interface
shared/           # Shared types and schemas
  schema.ts       # Drizzle schema and TypeScript types
attached_assets/  # Static images and design references
```

### Design System
- **Theme**: White/light theme with professional blue accents
- **Typography**: DM Sans, Geist Mono fonts
- **Spacing**: Tailwind spacing units (4, 6, 8, 12, 16, 20, 24, 32)
- **Components**: Cards with subtle shadows, clean form inputs, elevated buttons
- **Animations**: Fade and slide entry animations, smooth scroll-triggered effects

## External Dependencies

### Payment Services
- **PayPal**: Server SDK (`@paypal/paypal-server-sdk`) for payment processing
  - Requires `PAYPAL_CLIENT_ID` and `PAYPAL_CLIENT_SECRET` environment variables
  - Critical integration code in `server/paypal.ts` must not be modified

### Email Services
- **EmailJS**: Browser-based email sending (`@emailjs/browser`)
  - Requires service ID, template ID, and public key configuration
  - Currently uses placeholder credentials in frontend

### Database
- **PostgreSQL**: Primary database (requires `DATABASE_URL` environment variable)
- **Drizzle ORM**: Type-safe database queries and migrations
- **connect-pg-simple**: Session storage for PostgreSQL

### UI Framework Dependencies
- **Radix UI**: Full suite of accessible primitive components
- **Tailwind CSS**: Utility-first styling with custom configuration
- **Framer Motion**: Animation library for React
- **Lucide React**: Icon library

### Development Tools
- **Vite**: Development server and build tool
- **esbuild**: Server-side bundling for production
- **TypeScript**: Type checking across frontend and backend