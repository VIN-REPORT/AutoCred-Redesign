import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import PayPalButton from "./PayPalButton";

interface PayPalWrapperProps {
  amount: string;
  currency: string;
  intent: string;
  onSuccess: () => void;
  onError?: (error: string) => void;
}

export default function PayPalWrapper({
  amount,
  currency,
  intent,
  onSuccess,
  onError,
}: PayPalWrapperProps) {
  const [paypalConfigured, setPaypalConfigured] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [paymentStarted, setPaymentStarted] = useState(false);

  useEffect(() => {
    const checkPayPalConfig = async () => {
      try {
        const response = await fetch("/api/paypal/setup");
        const data = await response.json();
        setPaypalConfigured(!data.error);
      } catch {
        setPaypalConfigured(false);
      } finally {
        setIsLoading(false);
      }
    };
    checkPayPalConfig();
  }, []);

  useEffect(() => {
    if (!paypalConfigured) return;

    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
      const response = await originalFetch.apply(this, args);
      
      const url = typeof args[0] === 'string' ? args[0] : (args[0] as Request).url;
      if (url.includes('/api/paypal/order/') && url.includes('/capture')) {
        setPaymentStarted(true);
        try {
          const clonedResponse = response.clone();
          const data = await clonedResponse.json();
          if (data.status === 'COMPLETED') {
            setTimeout(() => {
              onSuccess();
            }, 500);
          }
        } catch {
        }
      }
      
      return response;
    };

    return () => {
      window.fetch = originalFetch;
    };
  }, [paypalConfigured, onSuccess]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!paypalConfigured) {
    return (
      <div className="space-y-4 text-center">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-amber-800 text-sm">
            PayPal is not configured. Please contact support or add your PayPal credentials to enable payments.
          </p>
        </div>
        <Button 
          variant="outline" 
          className="w-full"
          onClick={onSuccess}
          data-testid="button-demo-complete"
        >
          Demo: Complete Order (Testing Only)
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <PayPalButton amount={amount} currency={currency} intent={intent} />
      <p className="text-center text-xs text-muted-foreground">
        Complete your payment through PayPal's secure checkout.
      </p>
      {paymentStarted && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
          <p className="text-green-700 text-sm">
            Payment detected! Processing...
          </p>
        </div>
      )}
      <Button 
        variant="outline" 
        className="w-full"
        onClick={onSuccess}
        data-testid="button-payment-complete"
      >
        I've Completed Payment
      </Button>
    </div>
  );
}
