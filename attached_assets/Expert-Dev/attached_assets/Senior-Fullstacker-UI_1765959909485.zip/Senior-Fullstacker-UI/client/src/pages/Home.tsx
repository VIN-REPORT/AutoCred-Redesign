import { useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Check, Shield, Clock, Mail, Eye, Target, Users, Award, ChevronRight } from "lucide-react";
import emailjs from "@emailjs/browser";
import PayPalWrapper from "@/components/PayPalWrapper";

import carImage1 from "@assets/stock_images/modern_luxury_sedan__c1eedd36.jpg";
import carImage2 from "@assets/stock_images/modern_luxury_sedan__3de7556a.jpg";
import inspectionImage from "@assets/stock_images/car_inspection_mecha_4843106e.jpg";
import officerImage from "@assets/stock_images/professional_automot_fdf09074.jpg";

const vinFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Please enter a valid email address"),
  vinNumber: z.string()
    .length(17, "VIN must be exactly 17 characters")
    .regex(/^[A-HJ-NPR-Z0-9]+$/i, "VIN must contain only letters and numbers (no I, O, or Q)"),
});

const contactFormSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Please enter a valid email address"),
  vinNumber: z.string().optional(),
  message: z.string().min(1, "Message is required"),
});

type VinFormData = z.infer<typeof vinFormSchema>;
type ContactFormData = z.infer<typeof contactFormSchema>;

// EmailJS Configuration - Replace these with your actual credentials
// Get these from https://www.emailjs.com/
const EMAILJS_SERVICE_ID = "YOUR_SERVICE_ID";      // Replace with your EmailJS service ID
const EMAILJS_OWNER_TEMPLATE_ID = "YOUR_OWNER_TEMPLATE_ID";  // Template for owner notification
const EMAILJS_CLIENT_TEMPLATE_ID = "YOUR_CLIENT_TEMPLATE_ID"; // Template for client confirmation
const EMAILJS_PUBLIC_KEY = "YOUR_PUBLIC_KEY";      // Replace with your EmailJS public key

// Helper function to send emails via EmailJS
const sendOwnerNotification = async (data: VinFormData) => {
  try {
    await emailjs.send(
      EMAILJS_SERVICE_ID,
      EMAILJS_OWNER_TEMPLATE_ID,
      {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        vinNumber: data.vinNumber,
        timestamp: new Date().toLocaleString(),
      },
      EMAILJS_PUBLIC_KEY
    );
    console.log("Owner notification sent successfully");
  } catch (error) {
    console.error("Failed to send owner notification:", error);
  }
};

const sendClientConfirmation = async (data: VinFormData, type: "submission" | "payment") => {
  try {
    const message = type === "submission"
      ? "Thank you for submitting your VIN. Please complete payment to receive your report."
      : "Thank you for your payment. Your vehicle report is being generated. Maximum delivery time: 6 hours. Most reports are delivered within 10-15 minutes.";
    
    await emailjs.send(
      EMAILJS_SERVICE_ID,
      EMAILJS_CLIENT_TEMPLATE_ID,
      {
        to_name: data.firstName,
        to_email: data.email,
        message: message,
        vinNumber: data.vinNumber,
      },
      EMAILJS_PUBLIC_KEY
    );
    console.log("Client confirmation sent successfully");
  } catch (error) {
    console.error("Failed to send client confirmation:", error);
  }
};

const flags = [
  { country: "France", code: "fr" },
  { country: "United States", code: "us" },
  { country: "Canada", code: "ca" },
  { country: "Australia", code: "au" },
  { country: "United Kingdom", code: "gb" },
  { country: "New Zealand", code: "nz" },
];

const pricingFeatures = [
  "1 Vehicle Report",
  "Vehicle Specification",
  "DMV Title History",
  "Safety Recall Status",
  "Online Listing History",
  "Junk & Salvage Information",
  "Accident Information",
];

function AnimatedSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.section
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.section>
  );
}

function FlagCarousel() {
  const doubledFlags = [...flags, ...flags];

  return (
    <div className="overflow-hidden py-8">
      <motion.div
        className="flex gap-12"
        animate={{ x: [0, -50 * flags.length * 2] }}
        transition={{
          x: {
            repeat: Infinity,
            repeatType: "loop",
            duration: 20,
            ease: "linear",
          },
        }}
        style={{ width: "max-content" }}
      >
        {doubledFlags.map((flag, index) => (
          <div key={`${flag.code}-${index}`} className="flex flex-col items-center gap-3 min-w-[120px]">
            <img
              src={`https://flagcdn.com/w160/${flag.code}.png`}
              alt={flag.country}
              className="w-24 h-16 object-cover rounded-md shadow-md"
            />
            <span className="text-sm font-medium text-muted-foreground">{flag.country}</span>
          </div>
        ))}
      </motion.div>
    </div>
  );
}


export default function Home() {
  const { toast } = useToast();
  const [showPayment, setShowPayment] = useState(false);
  const [submittedData, setSubmittedData] = useState<VinFormData | null>(null);
  const reportFormRef = useRef<HTMLDivElement>(null);

  const vinForm = useForm<VinFormData>({
    resolver: zodResolver(vinFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      vinNumber: "",
    },
  });

  const contactForm = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      vinNumber: "",
      message: "",
    },
  });

  const scrollToReport = () => {
    reportFormRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const onVinSubmit = async (data: VinFormData) => {
    try {
      await fetch("/api/vin-submission", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...data,
          timestamp: new Date().toISOString(),
        }),
      });

      // Send EmailJS notifications (will fail gracefully with placeholder credentials)
      sendOwnerNotification(data);
      sendClientConfirmation(data, "submission");

      setSubmittedData(data);
      setShowPayment(true);
      toast({
        title: "VIN Submitted Successfully",
        description: "Please complete payment to receive your report.",
      });
    } catch (error) {
      toast({
        title: "Submission Error",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  };

  const onContactSubmit = async (data: ContactFormData) => {
    try {
      await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      toast({
        title: "Message Sent",
        description: "We'll get back to you soon!",
      });
      contactForm.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePaymentSuccess = () => {
    if (submittedData) {
      // Send payment confirmation email
      sendClientConfirmation(submittedData, "payment");
    }
    toast({
      title: "Payment Successful",
      description: "Your vehicle report is being generated. Maximum delivery time: 6 hours. Most reports delivered within 10-15 minutes.",
    });
    setShowPayment(false);
    setSubmittedData(null);
    vinForm.reset();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-slate-50 via-white to-blue-50 py-20 lg:py-28 overflow-hidden">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight" data-testid="text-hero-headline">
                Get a Clear Picture Before You Buy
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-xl">
                Protect yourself from buying a used car with hidden problems. Our comprehensive inspections give you the information you need to make a confident decision.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button 
                  size="lg" 
                  onClick={scrollToReport}
                  className="px-8"
                  data-testid="button-get-report"
                >
                  Get Report
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  onClick={() => document.getElementById("about-us")?.scrollIntoView({ behavior: "smooth" })}
                  className="px-8"
                  data-testid="button-learn-more"
                >
                  Learn More
                </Button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <img
                src={carImage1}
                alt="Luxury vehicle"
                className="w-full rounded-2xl shadow-2xl"
                data-testid="img-hero-car"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Service Tagline Section */}
      <AnimatedSection className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                AutoCheckPro Service
              </h2>
              <p className="text-lg text-muted-foreground">
                We ensure your car is in perfect condition with our comprehensive inspection reports.
              </p>
            </div>
            <div>
              <img
                src={inspectionImage}
                alt="Car inspection service"
                className="w-full rounded-xl shadow-lg"
                data-testid="img-service"
              />
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* VIN Report Form Section */}
      <AnimatedSection className="py-20 bg-slate-50" id="report">
        <div className="container mx-auto px-4 max-w-3xl" ref={reportFormRef}>
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Get Your Report Now
            </h2>
            <p className="text-muted-foreground">
              Enter your vehicle information to receive a comprehensive history report.
            </p>
          </div>
          
          <Card className="shadow-xl border-0">
            <CardContent className="p-8">
              {!showPayment ? (
                <Form {...vinForm}>
                  <form onSubmit={vinForm.handleSubmit(onVinSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={vinForm.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input placeholder="John" {...field} data-testid="input-first-name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={vinForm.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Doe" {...field} data-testid="input-last-name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={vinForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="john@example.com" {...field} data-testid="input-email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={vinForm.control}
                      name="vinNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Car VIN Number</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter 17-character VIN" 
                              maxLength={17}
                              {...field} 
                              onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                              data-testid="input-vin"
                            />
                          </FormControl>
                          <FormMessage />
                          <p className="text-xs text-muted-foreground mt-1">
                            VIN must be exactly 17 alphanumeric characters
                          </p>
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full" size="lg" data-testid="button-submit-vin">
                      Submit
                    </Button>
                  </form>
                </Form>
              ) : (
                <div className="space-y-6">
                  <div className="text-center">
                    <Shield className="w-16 h-16 mx-auto text-primary mb-4" />
                    <h3 className="text-2xl font-bold mb-2">Complete Your Payment</h3>
                    <p className="text-muted-foreground">
                      Thank you for submitting your VIN. Please complete payment to receive your report.
                    </p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg space-y-2">
                    <p><strong>VIN:</strong> {submittedData?.vinNumber}</p>
                    <p><strong>Email:</strong> {submittedData?.email}</p>
                  </div>
                  <PayPalWrapper 
                    amount="20.00" 
                    currency="USD" 
                    intent="CAPTURE"
                    onSuccess={handlePaymentSuccess}
                  />
                  <p className="text-center text-sm text-muted-foreground">
                    Maximum delivery time: 6 hours. Most reports delivered within 10-15 minutes.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </AnimatedSection>

      {/* Where We Provide Service */}
      <AnimatedSection className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-7xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Where We Provide Service
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Serving Customers Across the World
          </p>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            We proudly offer our services throughout the World.
          </p>
          <FlagCarousel />
        </div>
      </AnimatedSection>

      {/* About Us Section */}
      <AnimatedSection className="py-20 bg-slate-50" id="about-us">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <img
                src={carImage2}
                alt="Car inspection"
                className="w-full rounded-xl shadow-lg"
                data-testid="img-about"
              />
            </motion.div>
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">About Us</h2>
              <h3 className="text-2xl font-semibold text-foreground">
                Your Trusted Car Inspection Experts
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                AutoCheckPro: Unbiased car inspections for confident decisions. Certified inspectors provide clear, comprehensive evaluations of your vehicle's condition.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                We assess everything from engine to tires, using advanced tools to find potential problems. Receive a clear report outlining needed repairs or maintenance.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                AutoCheckPro is committed to integrity and customer satisfaction. Our passionate team provides exceptional service, building trust and exceeding expectations. Choose AutoCheckPro for peace of mind.
              </p>
              <Button onClick={scrollToReport} className="mt-4" data-testid="button-about-get-report">
                Get Your Report
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Our History Section */}
      <AnimatedSection className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our History</h2>
            <h3 className="text-xl text-muted-foreground">Our Journey Through Excellence</h3>
            <p className="text-muted-foreground mt-4 max-w-3xl mx-auto">
              From humble beginnings to a globally trusted automotive service, AutoCheckPro has grown by prioritizing customer satisfaction and reliable vehicle evaluations.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="shadow-lg">
              <CardHeader className="flex flex-row items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Eye className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl">Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To be the leading provider of trusted and accurate automotive information, empowering vehicle owners worldwide.
                </p>
              </CardContent>
            </Card>
            <Card className="shadow-lg">
              <CardHeader className="flex flex-row items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Target className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl">Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  To deliver exceptional car inspection services, exceeding customer expectations through expertise, integrity, and transparency.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </AnimatedSection>

      {/* Why Choose Us Section */}
      <AnimatedSection className="py-20 bg-slate-100">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <p className="text-primary font-semibold mb-2">WHY CHOOSE US</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Expertise. Trust. Reliability.
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Your Trusted Automotive Partner: Reliable expertise, accurate data, and consistent support for a smooth automotive journey.
            </p>
          </div>
          <div className="grid lg:grid-cols-4 gap-8 items-start">
            <div className="lg:col-span-1">
              <img
                src={officerImage}
                alt="Automotive professional"
                className="w-full max-w-xs mx-auto rounded-xl shadow-lg"
                data-testid="img-officer"
              />
            </div>
            <div className="lg:col-span-3 grid md:grid-cols-3 gap-6">
              <Card className="shadow-lg text-center p-6">
                <div className="p-4 bg-primary/10 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Award className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-lg font-bold mb-2">Expertise</h4>
                <p className="text-muted-foreground text-sm">
                  Benefit from our knowledgeable team for informed decisions.
                </p>
              </Card>
              <Card className="shadow-lg text-center p-6">
                <div className="p-4 bg-primary/10 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-lg font-bold mb-2">Trustworthy Information</h4>
                <p className="text-muted-foreground text-sm">
                  Rely on accurate data for peace of mind.
                </p>
              </Card>
              <Card className="shadow-lg text-center p-6">
                <div className="p-4 bg-primary/10 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <h4 className="text-lg font-bold mb-2">Dependable Support</h4>
                <p className="text-muted-foreground text-sm">
                  Count on us for consistent, reliable assistance throughout your automotive journey.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Pricing Section */}
      <AnimatedSection className="py-20 bg-white" id="pricing">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <p className="text-primary font-semibold mb-2">Pricing</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              AutoCheckPro Plan
            </h2>
            <p className="text-muted-foreground">
              Choose from our competitively priced plans, designed to fit your budget and meet your automotive needs.
            </p>
          </div>
          <div className="max-w-md mx-auto">
            <Card className="shadow-2xl border-2 border-primary/20">
              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl">Our Plan</CardTitle>
                <div className="mt-4">
                  <span className="text-sm text-muted-foreground">PRICE</span>
                  <div className="text-5xl font-bold text-primary mt-1" data-testid="text-price">
                    $20
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {pricingFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="p-1 bg-green-100 rounded-full">
                      <Check className="h-4 w-4 text-green-600" />
                    </div>
                    <span className="text-foreground">{feature}</span>
                  </div>
                ))}
                <div className="pt-4">
                  <Button 
                    className="w-full" 
                    size="lg" 
                    onClick={scrollToReport}
                    data-testid="button-pricing-get-report"
                  >
                    Get Report Now
                  </Button>
                </div>
                <p className="text-center text-sm text-muted-foreground pt-2">
                  Maximum delivery: 6 hours | Most reports: 10-15 min
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </AnimatedSection>

      {/* Contact Us Section */}
      <AnimatedSection className="py-20 bg-slate-50" id="contact">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Contact Us</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Have questions or need assistance? Contact us today for personalized support and expert guidance on all things automotive.
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-12">
            <div className="space-y-8">
              <h3 className="text-2xl font-bold text-foreground">Get in Touch</h3>
              <p className="text-muted-foreground">
                We are here to help you with any queries or support you need regarding our services. Our team responds quickly!
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Email:</p>
                    <a href="mailto:support@autocheckpro.com" className="text-primary hover:underline" data-testid="link-email">
                      support@autocheckpro.com
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Response Time:</p>
                    <p className="text-muted-foreground">Within 24 hours</p>
                  </div>
                </div>
              </div>
            </div>
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <Form {...contactForm}>
                  <form onSubmit={contactForm.handleSubmit(onContactSubmit)} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <FormField
                        control={contactForm.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input placeholder="John" {...field} data-testid="contact-input-first-name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={contactForm.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Doe" {...field} data-testid="contact-input-last-name" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={contactForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="john@example.com" {...field} data-testid="contact-input-email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={contactForm.control}
                      name="vinNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Car VIN Number (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter VIN if applicable" {...field} data-testid="contact-input-vin" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={contactForm.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="How can we help you?" 
                              className="min-h-[120px]"
                              {...field} 
                              data-testid="contact-input-message"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full" data-testid="button-contact-submit">
                      Submit
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </AnimatedSection>

      {/* Trust Badges Section */}
      <AnimatedSection className="py-16 bg-white border-t">
        <div className="container mx-auto px-4 max-w-7xl">
          <p className="text-center text-muted-foreground mb-8">
            The AutoCheckPro Report includes information gathered from the industry's most known and trustworthy data providers and specialists.
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
            <div className="text-center">
              <div className="bg-slate-100 px-6 py-4 rounded-lg">
                <span className="font-bold text-lg text-foreground">NMVTIS</span>
              </div>
            </div>
            <div className="text-center">
              <div className="bg-slate-100 px-6 py-4 rounded-lg">
                <span className="font-bold text-lg text-foreground">Kelley Blue Book</span>
              </div>
            </div>
            <div className="text-center">
              <div className="bg-slate-100 px-6 py-4 rounded-lg">
                <span className="font-bold text-lg text-foreground">J.D. Power</span>
              </div>
            </div>
            <div className="text-center">
              <div className="bg-slate-100 px-6 py-4 rounded-lg">
                <span className="font-bold text-lg text-foreground">NADA</span>
              </div>
            </div>
          </div>
        </div>
      </AnimatedSection>

      {/* Disclaimer Section */}
      <section className="py-12 bg-slate-100">
        <div className="container mx-auto px-4 max-w-7xl">
          <h3 className="text-xl font-bold text-foreground mb-4">Disclaimer</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">
            Dear loyal Customers, We are approved licensed resellers of NMVTIS data supplier, and we solely employ SEO and Social Media Marketing to drive visitors to our website by delivering accurate and comprehensive information.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-slate-900 text-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <h4 className="text-xl font-bold">AutoCheckPro</h4>
              <p className="text-slate-400 text-sm">
                Your trusted partner for comprehensive vehicle history reports.
              </p>
            </div>
            <div className="space-y-4">
              <h5 className="font-semibold">Quick Links</h5>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#report" className="hover:text-white transition-colors">Get Report</a></li>
                <li><a href="#about-us" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div className="space-y-4">
              <h5 className="font-semibold">Coverage</h5>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>United States</li>
                <li>Canada</li>
                <li>United Kingdom</li>
                <li>Australia</li>
                <li>France</li>
                <li>New Zealand</li>
              </ul>
            </div>
            <div className="space-y-4">
              <h5 className="font-semibold">Legal</h5>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Refund Policy</a></li>
              </ul>
              <div className="pt-4 text-xs text-slate-500">
                <p>No refunds after 1 hour of purchase.</p>
                <p>Digital service for informational purposes only.</p>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400 text-sm">
            <p>&copy; {new Date().getFullYear()} AutoCheckPro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
